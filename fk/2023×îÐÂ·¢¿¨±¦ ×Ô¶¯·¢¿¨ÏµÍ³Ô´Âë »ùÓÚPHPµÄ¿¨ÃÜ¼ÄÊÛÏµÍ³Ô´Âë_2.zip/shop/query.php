<?php
require '../conn/conn.php';
require '../conn/function.php';

require 'template/'.$C_shopt.'/query.php';
?>