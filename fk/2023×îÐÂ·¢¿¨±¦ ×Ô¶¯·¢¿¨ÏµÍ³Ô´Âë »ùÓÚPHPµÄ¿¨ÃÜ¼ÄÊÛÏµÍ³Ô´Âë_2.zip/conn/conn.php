<?php
$db=array(
	"servername" => "127.0.0.1",
	"username" => "root",
	"password" => "rootroot",
	"dbname" => "db6001"
);
?>